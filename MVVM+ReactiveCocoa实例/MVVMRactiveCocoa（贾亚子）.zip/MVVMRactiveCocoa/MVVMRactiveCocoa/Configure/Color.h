//
//  DBColor.h
//  danbai_client_ios
//
//  Created by 赵璞 on 15/6/24.
//  Copyright (c) 2015年 db. All rights reserved.
//  颜色宏定义

#ifndef danbai_client_ios_DBColor_h
#define danbai_client_ios_DBColor_h


/** 颜色 */
#define DBRGBA(r,g,b,a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]
#define DBColor(r, g, b) DBRGBA(r,g,b,1.0f)

#define DBColorFromRGB(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define DBColorFromRGBWithAlpha(rgbValue,a) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:a]


//c1 导航栏标题字体颜色和按钮
#define DBTextThemeColor DBColorFromRGB(0x970128)

//c2 正文内容颜色
#define c2 DBColorFromRGB(0x565656)

//c3 输入框内的文字颜色
#define c3 DBColorFromRGB(0x8c8b8b)

//c4 导航栏背景，标签栏背景
#define DBThemeColor DBColorFromRGB(0xffe4d6)

//c5 标签栏文字颜色
#define c5 DBColorFromRGB(0x000000)

//c6 链接文字颜色（此文字一般有下划线）
#define c6 DBColorFromRGB(0x366dd2)

//c7 圆角矩形输入框边框颜色
#define c7 DBColorFromRGB(0xa5a5a5)

//c8 按钮背景
#define c8 DBColorFromRGB(0xffffff)


#define C1 DBColorFromRGB(0xdf184d)
#define C2 DBColorFromRGB(0x000000)//黑色
#define C3 DBColorFromRGB(0x232323)
#define C4 DBColorFromRGB(0xffffff)//白色
#define C5 DBColorFromRGB(0xe5e5e5)//分割线
#define C6 DBColorFromRGB(0xf9f9f9)//背景色
#define C7 DBColorFromRGB(0x666666)
#define C8 DBColorFromRGB(0x999999)
#define C9 DBColorFromRGB(0x71cec1)
#define C10 DBColorFromRGB(0x087eda)


#endif

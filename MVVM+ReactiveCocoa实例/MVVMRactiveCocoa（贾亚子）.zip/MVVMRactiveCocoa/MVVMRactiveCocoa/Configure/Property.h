//
//  DBProperty.h
//  danbai_client_ios
//
//  Created by 赵璞 on 15/6/25.
//  Copyright (c) 2015年 db. All rights reserved.
//

#ifndef danbai_client_ios_DBProperty_h
#define danbai_client_ios_DBProperty_h

/** 社团名字的字体 */
#define DBOgzNameFont [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:17],NSFontAttributeName, nil]
/** 其他的字体 */
#define DBOtherFont [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:15],NSFontAttributeName, nil]
/** 字体 */
#define DBTwoFont [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:13],NSFontAttributeName, nil]

/** 表格的边框宽度 */
#define DBTableBorder 5
/** cell的边框宽度 */
#define DBCellBorder 14

#define Border8  4
#define Border10 5
#define Border12 6
#define Border14 7
#define Border16 8
#define Border18 9
#define Border20 10
#define Border22 11
#define Border24 12
#define Border26 13
#define Border28 14
#define Border30 15
#define Border32 16
#define Border34 17
#define Border36 18
#define Border38 19
#define Border44 22
#define Border48 24
#define Border50 25
#define Border58 29






//大标题/头部导航
#define Z36 [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:18],NSFontAttributeName, nil]
//
#define Z34 [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:17],NSFontAttributeName, nil]
//大按钮、一级tab、短片大标题、头部导航右上角文字
#define Z30 [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:15],NSFontAttributeName, nil]
//小按钮、二级tab、弹窗上文字
#define Z28 [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:14],NSFontAttributeName, nil]
//短片正文、输入框文字大小+栏目栏、空数据提示
#define Z26 [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:13],NSFontAttributeName, nil]
//评论人名、分享弹窗图标文字
#define Z24 [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:12],NSFontAttributeName, nil]
//评论文本、注释说明
#define Z22 [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:11],NSFontAttributeName, nil]
//小小按钮
#define Z20 [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:10],NSFontAttributeName, nil]
//人数、社团id
#define Z18 [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:9],NSFontAttributeName, nil]
//时间+评论栏目栏
#define Z16 [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:8],NSFontAttributeName, nil]

#define iconW_bigbig 70
#define iconW_big 40
#define iconW_middle 35
#define iconW_small 20


#endif

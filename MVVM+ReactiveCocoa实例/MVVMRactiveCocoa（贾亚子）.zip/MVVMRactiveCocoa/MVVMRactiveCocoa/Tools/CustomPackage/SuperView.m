//
//  SuperView.m
//  danbai_client_ios
//
//  Created by 赵璞 on 15/6/15.
//  Copyright (c) 2015年 db. All rights reserved.
//

#import "SuperView.h"

@implementation SuperView

//获取父控制器
+ (UIViewController *)getViewController:(UIView *)curView {
    for (UIView* next = [curView superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}

@end

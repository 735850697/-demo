//
//  SuperView.h
//  danbai_client_ios
//
//  Created by 赵璞 on 15/6/15.
//  Copyright (c) 2015年 db. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SuperView : NSObject

+ (UIViewController *)getViewController:(UIView *)curView;

@end

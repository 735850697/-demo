//
//  NSDate+Addition.h
//  danbai_client_ios
//
//  Created by 赵璞 on 15/7/23.
//  Copyright (c) 2015年 db. All rights reserved.
//



@interface NSDate (Addition)

// 生成时间间隔字符串（生成时间差）
- (NSString *)diff2now;
- (NSDateComponents *)components;




@end

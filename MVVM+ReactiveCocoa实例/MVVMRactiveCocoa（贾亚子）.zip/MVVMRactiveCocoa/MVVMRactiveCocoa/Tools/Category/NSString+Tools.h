//
//  NSString+Tools.h
//  danbai_client_ios
//
//  Created by 赵璞 on 15/6/13.
//  Copyright (c) 2015年 db. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Tools)

//验证手机号码
- (BOOL)validateMobile;

//验证身份证号
- (BOOL) validateIdentityCard;

//真实姓名
- (BOOL) validateTrueName;

//判断是否有特殊符号
- (BOOL)effectivePassword;

//匹配首尾空白字符
-(BOOL) validateBlankString;


//判断手机型号
+ (NSString *)deviceString;



/*
 *
 *提供城市名字，返回城市代码
 */
+ (NSString *)cityDictionary:(NSString *)cityKey valueForKey:(NSString *)value;


//提供城市代码，返回城市名字
+ (NSString *)cityDictionary2:(NSString *)cityKey valueForKey:(NSString *)value;


- (CGSize)sizeWithFont:(UIFont *)font;


- (CGSize)sizeWithFont:(UIFont *)font constrainedToSize:(CGSize)size;


@end

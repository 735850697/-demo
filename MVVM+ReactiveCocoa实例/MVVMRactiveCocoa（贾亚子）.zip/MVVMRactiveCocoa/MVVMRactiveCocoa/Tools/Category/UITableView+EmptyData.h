//
//  UITableView+EmptyData.h
//  danbai_client_ios
//
//  Created by 赵璞 on 15/11/3.
//  Copyright © 2015年 db. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (EmptyData)


- (void)tableViewDisplayWithMessage:(NSString *) message ifNecessaryForRowCount:(NSUInteger) rowCount;

@end

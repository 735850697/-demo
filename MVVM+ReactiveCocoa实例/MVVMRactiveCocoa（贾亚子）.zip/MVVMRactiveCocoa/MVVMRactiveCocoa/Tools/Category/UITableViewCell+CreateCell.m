//
//  UITableViewCell+CreateCell.m
//  danbai_client_ios
//
//  Created by 赵璞 on 15/6/16.
//  Copyright (c) 2015年 db. All rights reserved.
//

#import "UITableViewCell+CreateCell.h"

@implementation UITableViewCell (CreateCell)

+ (UITableViewCell *)cellWithTableView:(UITableView *)tableView
{
    NSString *identifer = NSStringFromClass([self class]);
    return [self cellWithTableView:tableView identifer:identifer];
}

/**
 *  根据tableView、identifer创建对应的cell
 *
 *  @param tableView tableView
 *  @param identifer cell的重用标识
 *
 *  @return 返回对应的cell
 */
+ (UITableViewCell *)cellWithTableView:(UITableView *)tableView identifer:(NSString *)identifer
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifer];
    if (!cell) {
        BOOL isExist = [self fileIsExistWithNibName:identifer];
        if (isExist) {
            cell = [[[NSBundle mainBundle] loadNibNamed:identifer owner:self options:nil] lastObject];
        }
        else
        {
            cell = [[NSClassFromString(identifer) alloc] init];
        }
        
//        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return cell;
}

/**
 *  判断指定的xib是否存在
 *
 *  @param nibName nib名
 *
 *  @return 是否存在指定的nib文件
 */
+ (BOOL)fileIsExistWithNibName:(NSString *)nibName
{
    NSString *bundlePath = [NSBundle mainBundle].bundlePath;
    NSString *nibPath = [bundlePath stringByAppendingFormat:@"/%@.xib",nibName];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    return [fileManager fileExistsAtPath:nibPath];
}

+ (UITableViewCell *)cellWithTableViewNib:(UITableView *)tableView {
    NSString *identifer = NSStringFromClass([self class]);
    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:identifer];
    if (cell == nil)
    {
        cell=[[[NSBundle mainBundle]loadNibNamed:identifer owner:self options:nil]lastObject];
    }

    return cell;
}


@end

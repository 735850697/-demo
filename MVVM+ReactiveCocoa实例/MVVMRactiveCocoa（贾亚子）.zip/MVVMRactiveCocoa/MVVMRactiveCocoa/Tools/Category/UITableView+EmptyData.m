//
//  UITableView+EmptyData.m
//  danbai_client_ios
//
//  Created by 赵璞 on 15/11/3.
//  Copyright © 2015年 db. All rights reserved.
//

#import "UITableView+EmptyData.h"
@implementation UITableView (EmptyData)


- (void)tableViewDisplayWithMessage:(NSString *) message ifNecessaryForRowCount:(NSUInteger) rowCount {
    if (rowCount == 0) {
        // Display a message when the table is empty
        // 没有数据的时候，UILabel的显示样式
        
//        DBBlankPageView *blankPageView = [[DBBlankPageView alloc]init];
//        blankPageView.backgroundColor = [UIColor clearColor];
//        blankPageView.frame = self.backgroundView.frame;
//        
//        blankPageView.label1.text = message;
        
        

        UILabel *messageLabel = [[UILabel alloc]init];
        messageLabel.text = message;
        messageLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        messageLabel.textColor = [UIColor grayColor];
        messageLabel.textAlignment = NSTextAlignmentCenter;
        [messageLabel sizeToFit];
        
        self.backgroundView = messageLabel;
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
    } else {
        self.backgroundView = nil;
        self.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    }
}



@end

//
//  UITableViewCell+CreateCell.h
//  danbai_client_ios
//
//  Created by 赵璞 on 15/6/16.
//  Copyright (c) 2015年 db. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCell (CreateCell)

/**
 *  根据tableView、重用标识 创建对应的cell
 *
 *  @param tableView tableView
 *
 *  @return 返回对应的cell
 */
+ (UITableViewCell *)cellWithTableView:(UITableView *)tableView;

/**
 *  创建nib的cell
 */
+ (UITableViewCell *)cellWithTableViewNib:(UITableView *)tableView;

@end

//
//  RequestData.h
//  danbai_client_ios
//
//  Created by 赵璞 on 15/7/10.
//  Copyright (c) 2015年 db. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^FailureBlock)(NSError *error);                // 请求失败的block
typedef void(^SuccessBlock)(id json);

@interface RequestData : NSObject

#pragma mark-------------------------用户------------------------------
/**
 *  初始化
 *  @param success 成功后的回调
 *  @param failure 失败后的回调
 */
+ (void)appStartUserSuccess:(SuccessBlock)success failure:(FailureBlock)failure;

/**
 *  获取验证码
 *  @param params      用户参数字典
 *  @param success     成功后的回调
 *  @param failure     失败后的回调
 */
+ (void)getVerificationWithParams:(NSMutableDictionary *)params success:(SuccessBlock)success failure:(FailureBlock)failure;


@end

//
//  RequestData.m
//  danbai_client_ios
//
//  Created by 赵璞 on 15/7/10.
//  Copyright (c) 2015年 db. All rights reserved.
//

#import "RequestData.h"
@implementation RequestData

#pragma mark-----------------------用户-------------------------------
+ (void)appStartUserSuccess:(SuccessBlock)success failure:(FailureBlock)failure{
    
}

+ (void)getVerificationWithParams:(NSMutableDictionary *)params success:(SuccessBlock)success failure:(FailureBlock)failure{
    
}
@end

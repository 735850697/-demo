//
//  BaseRequest.m
//  MVVMRactiveCocoa
//
//  Created by dbjyz on 15/11/9.
//  Copyright © 2015年 dbjyz. All rights reserved.
//

#import "BaseRequest.h"
#import <AFNetworking-RACExtensions/RACAFNetworking.h>
#import "ResponseData.h"
#import "APIRequestSerializer.h"

@implementation BaseRequest

+(BaseRequest *)sharedClient {
    static BaseRequest *_sharedClient = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedClient = [[BaseRequest alloc] initWithBaseURL:[NSURL URLWithString:@"http://localhost:12306/"]];//TODO
        
        AFSecurityPolicy *securityPolicy = [AFSecurityPolicy defaultPolicy];
        securityPolicy.allowInvalidCertificates = YES;
        _sharedClient.securityPolicy = securityPolicy;
        //序列化请求对象
        _sharedClient.requestSerializer = [APIRequestSerializer serializer];
    });
    
    return _sharedClient;
}


- (RACSignal *)httpGet:(NSString *)URLString parameters:(id)parameters {
    NSLog(@"url == %@",URLString);
    return [[[self rac_GET:URLString parameters:parameters]
             catch:^RACSignal *(NSError *error) {
                 //对Error进行处理
                 NSLog(@"error:%@", error);
                 //TODO: 这里可以根据error.code来判断下属于哪种网络异常，分别给出不同的错误提示
                 return [RACSignal error:[NSError errorWithDomain:@"ERROR" code:error.code userInfo:@{@"Success":@NO, @"Message":@"Bad Network!"}]];
             }]
            reduceEach:^id(id responseObject, NSURLResponse *response){
                NSLog(@"url:%@,resp:%@",response.URL.absoluteString,responseObject);
                ResponseData *data = [ResponseData objectWithKeyValues:responseObject];
                
                return data;
            }];
}



- (RACSignal *)httpPost:(NSString *)URLString parameters:(id)parameters {
    return [[[self rac_POST:URLString parameters:parameters]
             catch:^RACSignal *(NSError *error) {
                 //对Error进行处理
                 NSLog(@"error:%@", error);
                 //TODO: 这里可以根据error.code来判断下属于哪种网络异常，分别给出不同的错误提示
                 return [RACSignal error:[NSError errorWithDomain:@"ERROR" code:error.code userInfo:@{@"Success":@NO, @"Message":@"Bad Network!"}]];
             }]
            reduceEach:^id(id responseObject, NSURLResponse *response){
                NSLog(@"url:%@,resp:%@",response.URL.absoluteString,responseObject);
                ResponseData *data = [ResponseData objectWithKeyValues:responseObject];
                
                return data;
            }];
    
}



-(RACSignal *)getUserData:(NSString *)uri param:(NSDictionary *)param{
    
    return [self httpGet:uri parameters:param];
}

@end

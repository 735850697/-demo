//
//  BaseRequest.h
//  MVVMRactiveCocoa
//
//  Created by dbjyz on 15/11/9.
//  Copyright © 2015年 dbjyz. All rights reserved.
//


#import <AFNetworking/AFNetworking.h>
@interface BaseRequest : AFHTTPSessionManager

//请求域名
+(BaseRequest *)sharedClient;
//get请求
- (RACSignal *)httpGet:(NSString *)URLString parameters:(id)parameters;
//post请求
- (RACSignal *)httpPost:(NSString *)URLString parameters:(id)parameters;



//获取个人信息
-(RACSignal *)getUserData:(NSString *)url param:(NSDictionary *)param;

@end

//
//  APIRequestSerializer.h
//  MVVM
//
//  Created by develop on 15/9/17.
//  Copyright (c) 2015年 songhailiang. All rights reserved.
//

#import "AFURLRequestSerialization.h"

@interface APIRequestSerializer : AFHTTPRequestSerializer

@end

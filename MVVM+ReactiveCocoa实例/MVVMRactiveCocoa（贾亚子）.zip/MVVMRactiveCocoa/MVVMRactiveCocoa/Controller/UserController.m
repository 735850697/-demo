//
//  UserController.m
//  MVVMRactiveCocoa
//
//  Created by dbjyz on 15/11/9.
//  Copyright © 2015年 dbjyz. All rights reserved.
//

#import "UserController.h"
#import "UserCell.h"
#import "UserModel.h"
@interface UserController()<UITableViewDataSource,UITableViewDelegate>
@property(strong, nonatomic)UITableView * tableView;
@end

@implementation UserController

-(void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self loadTableView];
    [self initViewModel];
}

//处理键盘问题
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.view.shiftHeightAsDodgeViewForMLInputDodger = 50.0f;
    [self.view registerAsDodgeViewForMLInputDodger];
}


- (void)initViewModel {
    
    //初始化ViewModel
    _userCellViewModel = [[UserCellViewModel alloc] init];
    
    //数据绑定（数据虽然绑定，但也需要我们触发，只是他会判断数据是否改变，改变的话才会执行block）
    @weakify(self)
    [RACObserve(self, self.userCellViewModel.UserDataArr) subscribeNext:^(id x) {
        @strongify(self);//强引用转换，强引用转换（达到双向的作用）
        [self.tableView reloadData];
        [self.tableView.header endRefreshing];
    }];
    
     [self.tableView .header beginRefreshing];
}



-(void)loadTableView{
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height) style:UITableViewStylePlain];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    
    [self.view addSubview:_tableView];
}


#pragma Mark-tableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.userCellViewModel.UserDataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UserCell * userCell = [tableView dequeueReusableCellWithIdentifier:@"userCell"];
    if (!userCell) {
        userCell = [[UserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"customCell"];
    }
    userCell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    
    
    //监听
    [[[userCell.userTextField.rac_textSignal
       map:^id(NSString*text){
           return @(text.length);
       }]
      filter:^BOOL(NSNumber*length){
          return[length integerValue] > 3;
      }]
     subscribeNext:^(id x){
         userCell.submitButton.backgroundColor = [UIColor redColor];
         userCell.submitButton.userInteractionEnabled = YES;
     }];
    

    //给cell赋值
    UserModel * userModel = [self.userCellViewModel.UserDataArr objectAtIndex:indexPath.row];
    userCell.userModel = userModel;
    return userCell;

}


-(void)loadData{
   [self.userCellViewModel.getUserCommand execute:nil];//执行这个动作，触发这个动作
}


-(void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];

}

@end

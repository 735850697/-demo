//
//  UserCell.m
//  MVVMRactiveCocoa
//
//  Created by dbjyz on 15/11/9.
//  Copyright © 2015年 dbjyz. All rights reserved.
//

#import "UserCell.h"
@interface UserCell()
@property(strong, nonatomic)UILabel * userNameLabel;


@end

@implementation UserCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self loadUserView];
    }
    return self;
}


//数据绑定
-(void)addData{
    @weakify(self);
    [RACObserve(self, userModel) subscribeNext:^(id x) {
        @strongify(self);
        _userNameLabel.text = self.userModel.userName;
    }];
}


//视图布局和赋值
-(void)loadUserView{
    _userNameLabel = [[UILabel alloc] init];
    _userTextField = [[UITextField alloc] init];
    _submitButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _submitButton.userInteractionEnabled = NO;
    [_submitButton setTitle:@"提交" forState:UIControlStateNormal];
    [_submitButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_submitButton addTarget:self action:@selector(submit) forControlEvents:UIControlEventTouchUpInside];
    
    _submitButton.backgroundColor = [UIColor grayColor];
    _userTextField.backgroundColor = [UIColor yellowColor];
    
    [self addSubview:_userNameLabel];
    [self addSubview:_userTextField];
    [self addSubview:_submitButton];
    [self layout];
    [self addData];
}


-(void)submit{
    NSLog(@"按钮可以点击了，开始提交");

}


//布局
-(void)layout{
    [_userNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).with.offset(5);
        make.left.equalTo(self).with.offset(20);
        make.bottom.equalTo(self).with.offset(-5);
        make.width.mas_equalTo(60);
    }];
    
    
    [_submitButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).with.offset(5);
        make.right.equalTo(self).with.offset(-5);
        make.bottom.equalTo(self).with.offset(-5);
        make.width.mas_equalTo(50);
    }];
    
    
    [_userTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).with.offset(5);
        make.left.equalTo(_userNameLabel.mas_right).with.offset(5);
        make.bottom.equalTo(self).with.offset(-5);
        make.right.equalTo(_submitButton.mas_left).with.offset(-5);
    }];
    
    
    
    
}

@end

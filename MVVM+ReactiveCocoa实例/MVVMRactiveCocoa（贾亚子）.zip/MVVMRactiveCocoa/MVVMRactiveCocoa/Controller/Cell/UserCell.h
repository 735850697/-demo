//
//  UserCell.h
//  MVVMRactiveCocoa
//
//  Created by dbjyz on 15/11/9.
//  Copyright © 2015年 dbjyz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserModel.h"

@interface UserCell : UITableViewCell
@property(strong, nonatomic)UserModel * userModel;

@property(strong, nonatomic)UITextField * userTextField;
@property(strong, nonatomic)UIButton * submitButton;

@end

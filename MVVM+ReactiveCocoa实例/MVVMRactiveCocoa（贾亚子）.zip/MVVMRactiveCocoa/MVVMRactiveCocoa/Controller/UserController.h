//
//  UserController.h
//  MVVMRactiveCocoa
//
//  Created by dbjyz on 15/11/9.
//  Copyright © 2015年 dbjyz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserCellViewModel.h"

@interface UserController : UIViewController
@property(strong, nonatomic)UserCellViewModel * userCellViewModel;

@end

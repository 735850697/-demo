//
//  UserModel.h
//  MVVMRactiveCocoa
//
//  Created by dbjyz on 15/11/9.
//  Copyright © 2015年 dbjyz. All rights reserved.
//


@interface UserModel : NSObject
@property(strong, nonatomic)NSString * userName;

@end

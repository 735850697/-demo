//
//  UserModel.m
//  MVVMRactiveCocoa
//
//  Created by dbjyz on 15/11/9.
//  Copyright © 2015年 dbjyz. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel


@end

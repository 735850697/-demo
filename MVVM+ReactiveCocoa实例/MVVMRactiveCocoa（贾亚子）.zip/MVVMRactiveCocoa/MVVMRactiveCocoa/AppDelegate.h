//
//  AppDelegate.h
//  MVVMRactiveCocoa
//
//  Created by dbjyz on 15/11/6.
//  Copyright © 2015年 dbjyz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


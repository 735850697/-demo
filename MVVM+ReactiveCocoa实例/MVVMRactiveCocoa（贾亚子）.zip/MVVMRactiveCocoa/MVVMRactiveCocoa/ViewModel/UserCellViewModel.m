//
//  UserViewModel.m
//  MVVMRactiveCocoa
//
//  Created by dbjyz on 15/11/9.
//  Copyright © 2015年 dbjyz. All rights reserved.
//

#import "UserCellViewModel.h"
#import "UserModel.h"
#import "ResponseData.h"
#import "BaseRequest.h"

@interface UserCellViewModel()
@property(strong, nonatomic)BaseRequest * userRequest;

@end

@implementation UserCellViewModel

- (instancetype)init {
    if (self = [super init]) {
        
        [self initCommand];
        [self initSubscribe];
    }
    return self;
}


//生成command对象 动作（每次刷新都会主发这个动作）
-(void)initCommand{
    
    _getUserCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal *(id input) {
        //由此生成信号，由此返回的值作为初始化command的参数
        NSDictionary *params = @{@"name":@"jiayazi"};
        return [[BaseRequest sharedClient]
                 getUserData:@"/userMassage" param:params];
    }];
}


//处理有command对象获取的数据
-(void)initSubscribe{
    
    //对数据进行处理 动作（每次初始化生成command对象是都会执行此方法 过滤）
    @weakify(self);
    [[_getUserCommand.executionSignals switchToLatest] subscribeNext:^(ResponseData *response) {
        NSLog(@"sss == %@",response.data);
        @strongify(self);
        if (!response.success) {
            NSLog(@"请求数据错误");
        }
        else {
            self.UserDataArr = [UserModel objectArrayWithKeyValuesArray:response.data];
            NSLog(@"aaaa == %@",_UserDataArr);
        }
    }];
}


@end

//
//  UserViewModel.h
//  MVVMRactiveCocoa
//
//  Created by dbjyz on 15/11/9.
//  Copyright © 2015年 dbjyz. All rights reserved.
//

#import "UserModel.h"
@interface UserCellViewModel : NSObject

@property(strong, nonatomic)NSArray * UserDataArr;
@property(strong, nonatomic)UserModel * userModel;


/**
 *  获取数据Command
 */
@property (nonatomic, strong, readonly) RACCommand *getUserCommand;
@end
